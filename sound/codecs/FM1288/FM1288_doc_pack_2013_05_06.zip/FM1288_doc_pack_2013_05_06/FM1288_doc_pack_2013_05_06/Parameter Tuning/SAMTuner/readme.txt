1. SAMTunerV2_green_beta4.16_b26915.zip is green version for PC.(needn't setup)
2. SAMTunerV2_setup_beta4.16_b26915.exe is 32 bit setup version for PC.
3. SAMTunerV2_x64_setup_beta4.16_b26915.exe is 64 bit setup version for PC.